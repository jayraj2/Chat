﻿// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyBxhkOKc_tWaeeUSePIwitc2Tm-aqrLTww",
    authDomain: "chat-app-7da13.firebaseapp.com",
    databaseURL: "https://chat-app-7da13.firebaseio.com",
    projectId: "chat-app-7da13",
    storageBucket: "",
    messagingSenderId: "454878238535",
    appId: "1:454878238535:web:6fb06475d86f38e4"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
