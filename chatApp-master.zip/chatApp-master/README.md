# Chat App

I developed the Chat app using pure Javascript and firebase database. The interface of the App is similar to the WhatsApp web built by Bootstrap 4.0. This App feature includes

1. First design the interface of the chat app just like whatsapp using Bootstrap 
2. Design Testing on each device means Check Responsiveness 
3. Implement the functionality of chat using Firebase 
4. Upload code on GitHub 
5. Host website on GitHub 
6. Send image to other users 
7. Send Emoji 
8. Send Voice Message 
9. Push Notifications 
10. Send Friend Request

If you are interested that how to build this app, please follow my Youtube channel.

https://www.youtube.com/watch?v=RMvGcZfvj-8&list=PLa7L_AAYTxnX4jE6gIUkxBsqtPlFyt2Cn&index=1

